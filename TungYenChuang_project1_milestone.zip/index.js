//console.log("test")

var svg = d3.select("svg"),
    width = +svg.attr("width"),
    height = +svg.attr("height");

var format = d3.format(",d");

var color = d3.scaleOrdinal(d3.schemeCategory20c);
var pokecolor = {
	"Normal" : "#A8A77A",
	"Fire" :  "#EE8130",
	"Water" :  "#6390F0",
	"Electric" :  "#F7D02C",
	"Grass" :  "#7AC74C",
	"Ice" :  "#96D9D6",
	"Fighting" :  "#C22E28",
	"Poison" :  "#A33EA1",
	"Ground" :  "#E2BF65",
	"Flying" :  "#A98FF3",
	"Psychic" :  "#F95587",
	"Bug" :  "#A6B91A",
	"Rock" :  "#B6A136",
	"Ghost" :  "#735797",
	"Dragon" :  "#6F35FC",
	"Dark" :  "#705746",
	"Steel" :  "#B7B7CE",
	"Fairy" :  "#D685AD"
}

var pack = d3.pack()
    .size([width, height])
    .padding(1.5);

d3.csv("types.csv", function(d) {
	d.count = +d.count;
	if(d.count) return d;
}, function(err, classes){
	if(err) throw err;

	//console.log(classes);
	var root = d3.hierarchy({ "children" : classes})
				.sum(function(d){
					if(d.count) return d.count; 
				});
	//console.log(root);

	var node = svg.selectAll(".node")
    .data(pack(root).leaves())
    .enter().append("g")
      .attr("class", "node")
      .attr("transform", function(d) { return "translate(" + d.x + "," + d.y + ")"; });

  node.append("circle")
      .attr("type", function(d) { return d.data.type; })
      .attr("r", function(d) { return d.r; })
      .style("fill", function(d, i) { return pokecolor[d.data.type]})
      .attr('stroke','black')
      .attr('stroke-width',0)
      .on('mouseover',function() {
        d3.select(this)
      	  .transition()
      	  .duration(1000)
      	  .attr("r", function(d) {return 1.1 * d.r} )
      })
      .on('mouseout',function () {
        d3.select(this)
          .transition()
          .duration(1000)
          .attr("r", function(d) {return d.r})
      })

  node.append("clipPath")
      .attr("type", function(d) { return "clip-" + d.data.type; })
      .append("use")
      .attr("xlink:href", function(d) { return "#" + d.data.type; });

  node.append("text")
      .attr("dy", ".3em")
      .attr("font-size","15px")
      .style("text-anchor", "middle")
      .text(function(d) {
      		console.log(d);
            return d.data.type + ": " + d.data.count;
      });

  node.append("title")
      .text(function(d) { return d.data.type + "\n" + format(d.data.count); });
});

